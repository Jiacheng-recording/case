from __future__ import print_function
import os
import argparse
import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim
from torchvision import datasets, transforms
from torch.autograd import Variable

from vgg import vgg
import shutil

# 1：训练，并且加入l1正则化 -sr --s 0.0001 在main.py文件里
# 2：执行剪枝操作 --model model_best.pth.tar --save pruned.pth.tar --percent 0.7 剪掉7成的特征图在prune文件里
# 3：再次进行微调操作 --refine pruned.pth.tar --epochs 40#在main.py执行
parser = argparse.ArgumentParser(description='PyTorch Slimming CIFAR training')
parser.add_argument('--dataset', type=str, default='cifar10',
                    help='training dataset (default: cifar10)')
parser.add_argument('--sparsity-regularization', '-sr', dest='sr', action='store_true',
                    help='train with channel sparsity regularization')
parser.add_argument('--s', type=float, default=0.0001,
                    help='scale sparse rate (default: 0.0001)')
parser.add_argument('--refine', default='', type=str, metavar='PATH',
                    help='refine from prune model')
parser.add_argument('--batch-size', type=int, default=100, metavar='N',
                    help='input batch size for training (default: 100)')
parser.add_argument('--test-batch-size', type=int, default=1000, metavar='N',
                    help='input batch size for testing (default: 1000)')
parser.add_argument('--epochs', type=int, default=5, metavar='N',
                    help='number of epochs to train (default: 160)')
parser.add_argument('--start-epoch', default=0, type=int, metavar='N',
                    help='manual epoch number (useful on restarts)')
parser.add_argument('--lr', type=float, default=0.1, metavar='LR',
                    help='learning rate (default: 0.1)')
parser.add_argument('--momentum', type=float, default=0.9, metavar='M',
                    help='SGD momentum (default: 0.9)')
parser.add_argument('--weight-decay', '--wd', default=1e-4, type=float,
                    metavar='W', help='weight decay (default: 1e-4)')
parser.add_argument('--resume', default='', type=str, metavar='PATH',
                    help='path to latest checkpoint (default: none)')
parser.add_argument('--no-cuda', action='store_true', default=False,
                    help='disables CUDA training')
parser.add_argument('--seed', type=int, default=1, metavar='S',
                    help='random seed (default: 1)')
parser.add_argument('--log-interval', type=int, default=100, metavar='N',
                    help='how many batches to wait before logging training status')
args = parser.parse_args()
args.cuda = not args.no_cuda and torch.cuda.is_available()
torch.manual_seed(args.seed)
if args.cuda:
    torch.cuda.manual_seed(args.seed)

kwargs = {'num_workers': 0, 'pin_memory': True} if args.cuda else {}
'''
num_workers 是多进程的加载数，
pin_memory：是否将数据保存在pin memory区，pin memory中的数据转到GPU会快一些。
'''
'''
# 训练数据集的加载器，自动将数据分割成batch，顺序随机打乱
batch_size = 32
trainloader= torch.utils.data.DataLoader(dataset=trainset ,
                                           batch_size=batch_size,
                                           drop_last = True ,      
                                           shuffle=True,
                                           num_workers=4)

dataset:这个就是PyTorch已有的数据读取接口（比如torchvision.datasets.ImageFolder）或者自定义的数据接口的输出，
该输出要么是torch.utils.data.Dataset类的对象，要么是继承自
torch.utils.data.Dataset类的自定义类的对象。
batch_size:每个batch加载多少个样本(默认: 1),根据具体情况设置即可。
shuffle:设置为True时会在每个epoch重新打乱数据(默认: False),一般在训练数据中会采用。
collate_fn (callable, optional):是用来处理不同情况下的输入dataset的封装，
一般采用默认即可，除非你自定义的数据读取输出非常少见。合并样本列表以形成一个 mini-batch. 
 #　callable可调用对象
batch_sampler:从注释可以看出，其和batch_size、shuffle等参数是互斥的，一般采用默认。
sampler:从代码可以看出，其和shuffle是互斥的，一般默认即可。
num_workers:从注释可以看出这个参数必须大于等于0，0的话表示数据导入在主进程中进行，
其他大于0的数表示通过多个进程来导入数据，可以加快数据导入速度。
pin_memory，注释写得很清楚了： pin_memory (bool, optional): 
如果为真，数据加载器将在返回张量之前将其复制到CUDA固定内存中,然后再返回它们.
timeout(numeric, optional):是用来设置数据读取的超时时间的，但超过这个时间还没读取到数据的话就会报错.
如果为正值，则为从工作人员收集批次的超时值.应始终是非负的,（默认：0）.
drop_last (bool, optional): 设定为 True 如果数据集大小不能被批量大小整除的时候, 
将丢掉最后一个不完整的batch,(默认：False).




'''
train_loader = torch.utils.data.DataLoader(
    datasets.CIFAR10('./data', train=True, download=True,
                   transform=transforms.Compose([
                       transforms.Pad(4),
                       transforms.RandomCrop(32),
                       transforms.RandomHorizontalFlip(),
                       transforms.ToTensor(),
                       transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5))
                   ])),
    batch_size=args.batch_size, shuffle=True, **kwargs)
test_loader = torch.utils.data.DataLoader(
    datasets.CIFAR10('./data', train=False, transform=transforms.Compose([
                       transforms.ToTensor(),
                       transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5))
                   ])),
    batch_size=args.test_batch_size, shuffle=True, **kwargs)

if args.refine:
    checkpoint = torch.load(args.refine)
    model = vgg(cfg=checkpoint['cfg'])#使用剪枝后的网络架构
    model.cuda()
    model.load_state_dict(checkpoint['state_dict'])
else:
    model = vgg()#构建模型
if args.cuda:
    model.cuda()#使用GPU跑

optimizer = optim.SGD(model.parameters(), lr=args.lr, momentum=args.momentum, weight_decay=args.weight_decay)

if args.resume:#继续训练
    if os.path.isfile(args.resume):
        print("=> loading checkpoint '{}'".format(args.resume))
        checkpoint = torch.load(args.resume)
        args.start_epoch = checkpoint['epoch']
        best_prec1 = checkpoint['best_prec1']
        model.load_state_dict(checkpoint['state_dict'])
        optimizer.load_state_dict(checkpoint['optimizer'])
        print("=> loaded checkpoint '{}' (epoch {}) Prec1: {:f}"
              .format(args.resume, checkpoint['epoch'], best_prec1))
    else:
        print("=> no checkpoint found at '{}'".format(args.resume))

def updateBN():
    for m in model.modules():#BN+lamde*L1
        if isinstance(m, nn.BatchNorm2d):#判断是否是bn层引入s
            m.weight.grad.data.add_(args.s*torch.sign(m.weight.data))  # L1 大于0为1 小于0为-1 0还是0


def train(epoch):
    model.train()#构造网络
    for batch_idx, (data, target) in enumerate(train_loader):#遍历数据
        if args.cuda:#batch数据传入cuda当中
            data, target = data.cuda(), target.cuda()
        data, target = Variable(data), Variable(target)
        optimizer.zero_grad()
        output = model(data)#前向传统计算当前损失
        loss = F.cross_entropy(output, target)
        loss.backward()#反向传播
        if args.sr:
            updateBN()
        optimizer.step()
        if batch_idx % args.log_interval == 0:#经过batch做一个展示
            print('Train Epoch: {} [{}/{} ({:.1f}%)]\tLoss: {:.6f}'.format(
                epoch, batch_idx * len(data), len(train_loader.dataset),
                100. * batch_idx / len(train_loader), loss.item()))

def test():#测试模型的效果
    model.eval()
    test_loss = 0
    correct = 0
    for data, target in test_loader:
        if args.cuda:
            data, target = data.cuda(), target.cuda()
        data, target = Variable(data, volatile=True), Variable(target)
        output = model(data)
        test_loss += F.cross_entropy(output, target, size_average=False).item() # sum up batch loss
        pred = output.data.max(1, keepdim=True)[1] # get the index of the max log-probability
        correct += pred.eq(target.data.view_as(pred)).cpu().sum()

    test_loss /= len(test_loader.dataset)
    print('\nTest set: Average loss: {:.4f}, Accuracy: {}/{} ({:.1f}%)\n'.format(
        test_loss, correct, len(test_loader.dataset),
        100. * correct / len(test_loader.dataset)))
    return correct / float(len(test_loader.dataset))

def save_checkpoint(state, is_best, filename='checkpoint.pth.tar'):
    torch.save(state, filename)
    if is_best:
        shutil.copyfile(filename, 'model_best.pth.tar')#保存当前的模型

best_prec1 = 0.
for epoch in range(args.start_epoch, args.epochs):
    if epoch in [args.epochs*0.5, args.epochs*0.75]:
        for param_group in optimizer.param_groups:
            param_group['lr'] *= 0.1
    train(epoch)
    prec1 = test()
    is_best = prec1 > best_prec1
    best_prec1 = max(prec1, best_prec1)
    save_checkpoint({
        'epoch': epoch + 1,#迭代次数
        'state_dict': model.state_dict(),#保存参数
        'best_prec1': best_prec1,#最好的一次效果
        'optimizer': optimizer.state_dict(),#优化器
    }, is_best)
#微调重新训练的模型再次保存